Description
===========

Simulation of the flight of hyperfast stars in the gravitational field of the galaxy.
